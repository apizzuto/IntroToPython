'''
TITLE: Exercise 3-1-b
AUTHOR: Alex Pizzuto
DATE: February 1, 2017
DESCRIPTION: A short program to print a poem 10 times
MODIFICATION HISTORY AND OUTSIDE RESOURCES: last updated Feb. 01

'''
poem="""This is a repetitive poem
It’s a poem that’s repetitive
Repeating my repetitiveness
In a repetitive poem
I like using repetition
I like writing poems
So I’ll be repetitive
And write a repetitive poem
Poems can be repetitive
Repetition can be a poem
Repeating repetitiveness repeatedly
In a poem in poetry that’s called a poem
Which is repetitive
Repetitive is this poem
This poem is repetitive
It’s repetition that’s repeated
In poetry of the use of a poem
Repeating poem repetitiveness
Is repetitive of a repetition
Repeated in a repeating, repetitive poem
Poetry is so repetitively repeated
Because a repetitive repeating repetitiveness repeated poem
Is repetitive."""
print(10*poem)
