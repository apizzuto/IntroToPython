'''
TITLE: Exercise 3-1-a
AUTHOR: Alex Pizzuto
DATE: February 1, 2017
DESCRIPTION: A short program to print a phrase 100 times
MODIFICATION HISTORY AND OUTSIDE RESOURCES: last updated Feb. 01

'''

st="All work and no play makes Jack a dull boy. "
print(100*st)
